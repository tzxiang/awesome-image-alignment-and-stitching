function setLegend(val)
global legendStr
legendStr = val;
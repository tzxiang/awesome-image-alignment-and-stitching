function setImg(img)
global origImg
origImg = img;
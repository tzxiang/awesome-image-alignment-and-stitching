function setDebug(val)
global debug
debug = val;
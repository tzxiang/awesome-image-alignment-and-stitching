function r = getImg
global origImg
r = origImg;
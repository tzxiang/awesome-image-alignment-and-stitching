function r = getDebug
global debug
r = debug;
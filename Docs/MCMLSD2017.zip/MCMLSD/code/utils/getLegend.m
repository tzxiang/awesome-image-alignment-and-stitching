function r = getLegend
global legendStr
r = legendStr;
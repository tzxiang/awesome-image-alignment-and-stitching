function [ R ] = sd_set_zero_boundary( A, bdry_width )
%Sets the boundary of a matrix to zeros

R = A;

R(1:bdry_width,:) = 0;  
R(end-bdry_width-1:end,:) = 0;
R(:,1:bdry_width) = 0;  
R(:,end-bdry_width-1:end) = 0;

end


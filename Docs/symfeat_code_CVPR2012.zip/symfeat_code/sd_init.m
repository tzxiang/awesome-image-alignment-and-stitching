%addpath(getenv('DCH_MATLAB'));
addpath(fullfile(pwd,'thirdparty'));
addpath(fullfile(pwd,'thirdparty/area_intersect_circle_analytical'));



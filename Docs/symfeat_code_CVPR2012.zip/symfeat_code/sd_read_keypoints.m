function feature_locs = sd_read_keypoints(fname)
% Columns on output file:
% x, y, scale, orientation, detector score
% Scale equals detector support size / 4

feature_locs = dlmread(fname, '', 1, 0);
feature_locs(:,1) = feature_locs(:,1) + 1;
feature_locs(:,2) = feature_locs(:,2) + 1;

assert(size(feature_locs,2) == 5);

end
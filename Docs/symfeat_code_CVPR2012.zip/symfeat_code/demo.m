%% Intensity base symmetry detector
sd_symi('clock.jpg', 'symi.ks');

%% Gradient based symmetry detector
sd_symg('clock.jpg', 'symg.ks')

%% Show keypoints
% Click on the image to see features around the mouse pointer. Once you hit
% a button on the keyboard this interactive mode is ended.
sd_show_keypoints('clock.jpg', 'symi.ks');

%%
figure
sd_show_keypoints('clock.jpg', 'symg.ks', 'top_n_score', 100);

%% Extract descriptor
sd_symd('clock.jpg', 'symd.ks', 'symd.desc', 'input_keypoints', 'symi.ks');

% Compute local symmetry distance image.
%
% Inputs:
%    symtype       : which type of symmetry, can be 'r' for rotational, 'v'
%                    for vertical, or 'h' for horizontal.
%    im            : the input image
%    w             : the weight matrix, should be square and side length
%                    should be an odd number.
%
% Output:
%    score : matrix of symmetry scores
% 
% EXAMPLE: sd_naive_symdist('r', image, ones(5));

function sd_imwrite_grayscale( A, bounds, output_file )
%Write the matrix as a (scaled) grayscale image

gray = mat2gray(A, bounds);
X = gray2ind(gray, 256);
rgb = X; % ind2rgb(X, jet(256));
% rgb_large = imresize(rgb, [h w]);
imwrite(rgb, output_file);

end

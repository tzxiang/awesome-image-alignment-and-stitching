function [] = sd_log(level, msg)
fprintf('>> %s\n', msg);
end
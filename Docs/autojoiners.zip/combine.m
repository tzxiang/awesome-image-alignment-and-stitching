function [canvas, energy] = combine(file,order,deb)
%Combine the images specified by order
%order(1) means the image is at the bottom most of the ordering
%ie. put down on the canvas first
%If deb = 1, only show the output picture
%It deb = 0, find the borders and comput the gradient across it
%also return the gradient across the borders (energy)

showpix = 0;

energy = 0;
canvas = im2double(imread(['global_' file{order(1)}(1:end-3) 'bmp']));
if deb == 0
    mask = im2double(imread(['mask_' file{order(1)}(1:end-3) 'bmp']));
    Ix = conv2(mask,[-1 0 1],'same');  % take x derivative 
    Iy = conv2(mask,[-1;0;1],'same');  % take y derivative
    border = abs(Ix)+abs(Iy);
end
for i = 2:length(order)
    mask = im2double(imread(['mask_' file{order(i)}(1:end-3) 'bmp']));
    index = find(mask==1);
    if deb == 0
        Ix = conv2(mask,[-1 0 1],'same');  % take x derivative 
        Iy = conv2(mask,[-1;0;1],'same');  % take y derivative
        tempborder = abs(Ix)+abs(Iy);
        border(index) = tempborder(index);
    end
    index = [index; index+size(canvas,1)*size(canvas,2); index+2*size(canvas,1)*size(canvas,2)];
    infi = im2double(imread(['global_' file{order(i)}(1:end-3) 'bmp']));
    canvas(index) = infi(index);
    if showpix == 1;
    figure(1)
    imagesc(canvas);
    figure(2)
    imagesc(border)
    pause
    end
end

if deb == 0
    grad = zeros(size(canvas(:,:,1)));
    for i = 1:3
        Ix = conv2(canvas(:,:,i),[-1 0 1],'same');  % take x derivative 
        Iy = conv2(canvas(:,:,i),[-1;0;1],'same');  % take y derivative
        grad = abs(Ix)+abs(Iy)+grad;
    end

    index = border>=1;
    
    energy = sum(sum(index.*grad))
    
    if showpix == 1
    tempcan = canvas;
    index = find(index);
    tempcan(index) = 0;
    tempcan(index+size(canvas,1)*size(canvas,2)) = 1;
    tempcan(index+size(canvas,1)*size(canvas,2)) = 0;
    figure(3);
    imagesc(tempcan);
    end
end
function [im2pts] = ptslocal(size2, im2loc, canim2pts)
% compute the new feature points in im2 given the points lying on the
% canvas

orig = [1, size2(1); size2(2), size2(1); size2(2), 1; 1, 1]';
H12 = computeS(im2loc,orig);
temp = [canim2pts'; ones(1,length(canim2pts))];
im2pts = (H12*temp)';
%H21*[orig; ones(1,4)]
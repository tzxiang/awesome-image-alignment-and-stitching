%Modified by Ekapol Chuangsuwnaich for use in Automatic joiners
%
% [num,loc1m,loc2m] = match(image1, image2)
%
% This function reads two images, finds their SIFT features, and
%   displays lines connecting the matched keypoints.  A match is accepted
%   only if its distance is less than distRatio times the distance to the
%   second closest match.
% It returns the number of matches displayed.
% ====Modified to Return the locations of the match in image1 and image2
% ====The points are in a Matrix of size match x 2
%
% Example: match('scene.pgm','book.pgm');

function [num,loc1m,loc2m] = match(image1, image2)

% Find SIFT keypoints for each image
if(exist(['SIFT_' image1(1:end-3) '.mat']))
    im1 = mean(imread(image1),3);
    stuff1 = load(['SIFT_' image1(1:end-3) '.mat'],'des','loc');
    des1 = stuff1.des;
    loc1 = stuff1.loc;
else
    [im1, des1, loc1] = sift(image1);
    des = des1;
    loc = loc1;
    save(['SIFT_' image1(1:end-3) '.mat'],'des','loc');
end
if(exist(['SIFT_' image2(1:end-3) '.mat']))
    im2 = mean(imread(image2),3);
    stuff2 = load(['SIFT_' image2(1:end-3) '.mat'],'des','loc');
    des2 = stuff2.des;
    loc2 = stuff2.loc;
else
    [im2, des2, loc2] = sift(image2);
    des = des2;
    loc = loc2;
    save(['SIFT_' image2(1:end-3) '.mat'],'des','loc');
end

% For efficiency in Matlab, it is cheaper to compute dot products between
%  unit vectors rather than Euclidean distances.  Note that the ratio of 
%  angles (acos of dot products of unit vectors) is a close approximation
%  to the ratio of Euclidean distances for small angles.
%
% distRatio: Only keep matches in which the ratio of vector angles from the
%   nearest to second nearest neighbor is less than distRatio.
distRatio = 0.6;   



% For each descriptor in the first image, select its match to second image.
des2t = des2';                          % Precompute matrix transpose
for i = 1 : size(des1,1)
   dotprods = des1(i,:) * des2t;        % Computes vector of dot products
   [vals,indx] = sort(acos(dotprods));  % Take inverse cosine and sort results

   % Check if nearest neighbor has angle less than distRatio times 2nd.
   if (vals(1) < distRatio * vals(2))
      match(i) = indx(1);
   else
      match(i) = 0;
   end
end

% %des1 = des1(1:10,:);
% %des2 = des2(1:20,:);
% 
% distRatio = 0.6
% dis = dist2(des2, des1);
% %imagesc(dis)
% %colormap(gray);
% [minval1,ind1] = min(dis);
% %size(minval1)
% m =0:(size(dis,2)-1);
% %size(ind1)
% dis((ind1+size(dis,1)*m)) = max(max(dis));
% %figure(2)
% %imagesc(dis)
% %colormap(gray);
% [minval2,ind2] = min(dis);
% match = zeros(size(des1,1),1);
% %size(des1)
% %size(ind1)
% d1 = find(minval1./minval2 < distRatio);
% d2 = ind1(d1);
% match(d1) = d2;

%prune the features that is not one to one
for i = 1:length(match)
    keep = match(i);
    temp = match-match(i);
    match(temp==0) = 0;
    match(i) = keep;
end

num = sum(match > 0);
%create the matrix that contains the matched locations
loc1m = zeros(num,2);
loc2m = zeros(num,2);
loc1m = [loc1(match>0,2),loc1(match>0,1)];
matchtemp = match(match>0);
loc2m = [loc2(matchtemp,2), loc2(matchtemp,1)];


% Create a new image showing the two images side by side.
% im3 = appendimages(im1,im2);
% 
% %Show a figure with lines joining the accepted matches.
% figure('Position', [100 100 size(im3,2) size(im3,1)]);
% colormap('gray');
% imagesc(im3);
% hold on;
% cols1 = size(im1,2);
% for i = 1: size(des1,1)
%   if (match(i) > 0)
% %     plot(loc1(i,2), loc1(i,1),'*');
% %     plot(loc2(match(i),2)+cols1, loc2(match(i),1),'*');
%     line([loc1(i,2) loc2(match(i),2)+cols1], ...
%          [loc1(i,1) loc2(match(i),1)], 'Color', 'c');
%   end
%   plot(loc1m(:,1), loc1m(:,2),'*');
%   plot(loc2m(:,1)+cols1, loc2m(:,2),'*');
% end
% hold off;

fprintf('Found %d matches.\n', num);





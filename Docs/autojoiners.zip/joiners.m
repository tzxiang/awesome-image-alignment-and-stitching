function [out,optorder,file] = joiners(namelist)
%automaticly joins the images in list in the file 'namelist'.
%namelist assumes this particular layout
%
%name1
%name2
%name3...
%

Tolerance = 20; %minimum number of points after RANSAC to be considered a joint pair
ordertype = 0; %1 - from high to low, 0 from low to high


%STEP1===================================================================
%read the files names
file = textread(namelist,'%s','delimiter','\n','whitespace','');
N = length(file);

matched = zeros(N,N); %keep track of which pair are joint
Stuff = cell(N,N); %data structure to keep stuff
Sizes = zeros(3,N);
Imloc = cell(N,1);
%match each pair of files
for i = 1:N
    Sizes(:,i) = size(imread(file{i}));
    Imloc{i} = [1, Sizes(1,i); Sizes(2,i), Sizes(1,i); Sizes(2,i), 1; 1, 1]';
    for j = 1:i
        if i == j
            %do nothing
            Stuff{i,j}.points =[];
            Stuff{i,j}.nums = 0;
        else
            fprintf(['Matching %d ' file{i} ' and %d ' file{j} '\n'], i, j);
            [num,loc1m,loc2m] = match(file{i},file{j});
            if num <= 4
                fprintf('No RANSAC used\n');
                outax = [];
                outay = [];
                outbx = [];
                outby = [];
            else
                [outax, outay, outbx, outby] = RANSAC2(loc1m(:,1), loc1m(:,2), loc2m(:,1), loc2m(:,2));
                fprintf('RANSAC found match %d\n',length(outax));
            end
            if length(outax) > Tolerance
                matched(i,j) = 1;
                matched(j,i) = 1;
                Stuff{i,j}.points = cat(2, outax, outay, outbx, outby);
                Stuff{i,j}.nums = length(outax);
                Stuff{j,i}.points = cat(2, outbx, outby, outax, outay);
                Stuff{j,i}.nums = Stuff{i,j}.nums;
            else
                matched(i,j) = 0;
                Stuff{i,j}.points = cat(2, outax, outay, outbx, outby);
                Stuff{i,j}.nums = length(outax);
                Stuff{j,i}.points = cat(2, outbx, outby, outax, outay);
                Stuff{j,i}.nums = Stuff{i,j}.nums;
            end
        end
    end
end

%prune the one that does not match any
removed = 0;
count = 1;
collected = sum(matched);
list = zeros(1,N);
for i = 1:N
    if collected(i) == 0
        fprintf([file{i} 'pruned.\n']);
        %file{i:end-1} = file{i+1:end};
        removed = removed + 1;
        list(i) = 1;
        %Stuff{i:end-1,:} = Stuff{i+1:end,:};
        %Stuff{:,i:end-1} = Stuff{:,i+1:end};
        %Imloc{i:end-1,:} = Imloc{i+1:end,:};
        Sizes(:,i:end-1) = Sizes(:,i+1:end);
    else
        newfile{count} = file{i};
        newImloc{count} = Imloc{i};
        count = count+1;
    end
end
file = newfile;
Imloc = newImloc;
counti = 1;
for i = 1:N
    if(list(i) == 1)
        %this got removed
    else
        countj = 1;
        for j = 1:N
            if(list(j) == 1)
                %this also got removed
            else
                matched(counti,countj) = matched(i,j);
                newStuff{counti,countj} = Stuff{i,j};
                countj = countj+1;
            end
        end
        counti = counti+1;
    end
end
Stuff = newStuff;
N = N-removed;
matched = matched(1:N,1:N);
Sizes = Sizes(:,1:N);
clear outax outay outbx outby best loc1m loc2m num newStuff newfile newImloc list

%STEP2====================================================================
%find the location of each warped image
%start from the middle piece (match with most)
used = zeros(1, N); %indicate whether an image is processed in the ordering
[blah,order] = sort(sum(matched), 'descend');
ind = order(1);
used(ind) = 1;
Que = []; %Q to keep track of order of usage to grow the picture
for i = 1:N
    if ind == i
        %do nothing
    else
        if matched(ind,i) == 1
            Imloc{i} = morphblank(Sizes(:,ind),Sizes(:,i),Imloc{ind},Imloc{i},Stuff{ind,i}.points(:,1:2),Stuff{ind,i}.points(:,3:4));
            used(i) = 1;
            Que = [Que i];
        else
            %do nothing
        end
    end
end

while(~isempty(Que)) %while Que is not empty, grow the picture
    ind = Que(end);
    Que = Que(1:end-1);
    for i = 1:N
        if (ind == i) || (used(i) == 1)
            %do nothing already matched
        else
            if matched(ind,i) == 1
                Imloc{i} = morphblank(Sizes(:,ind),Sizes(:,i),Imloc{ind},Imloc{i},Stuff{ind,i}.points(:,1:2),Stuff{ind,i}.points(:,3:4));
                used(i) = 1;
                Que = [Que i];
            else
                %do nothing because not matched
            end
        end
    end
end
%done aligning all images

%put them into a longggggg list of coordinates
frame = zeros(2,4*N);
for i = 0:N-1
    frame(:,i*4+1:(i+1)*4) = Imloc{i+1};
end
%imagesc(imread('b.jpg')); axis([-1000 1000 -1000 1000]);
%hold on
%plot(frame(1,:),frame(2,:),'*');

%find the global canvas
framexspan = ceil(max([frame(1,:)]))-floor(min([frame(1,:)]));
frameyspan = ceil(max([frame(2,:)]))-floor(min([frame(2,:)]));
if min(frame(1,:)) < 1
    xshift = -(1 - floor(min(frame(1,:))))
else
    xshift = 0
end
if min(frame(2,:)) < 1
    yshift = -(1 - floor(min(frame(2,:))))
else
    yshift = 0
end
canvas = [framexspan+1, frameyspan+1]
%global canvas is frameyspan+1 x framexspan+1
%realign image location
for i = 1:N
    Imloc{i}(1,:) = Imloc{i}(1,:) - xshift;
    Imloc{i}(2,:) = Imloc{i}(2,:) - yshift;
end
for i = 0:N-1
    frame(:,i*4+1:(i+1)*4) = Imloc{i+1};
end
%imagesc(imread('b.jpg')); axis([-1000 1000 -1000 1000]);
%hold on
%plot(frame(1,:),frame(2,:),'*');

%output the files seperatly in global canvas
for i = 1:N
    morphglobal(canvas, file{i}, Imloc{i});
end
%see what if no reorder at all gives you
ord = 1:N
deb = 1;
out = combine(file,ord,deb);
display('Output before reordering');
figure();
imagesc(out);
imwrite(out, 'step2.jpg');
pause

clear out frame framexspan frameyspan blah

%STEP3====================================================================
%reorder
%do a non-optimal ordering by ordering adding one picture at a time
deb = 0;

if ordertype == 0
    used = zeros(1, N); %indicate whether an image is processed in the ordering
    [blah,order] = sort(sum(matched), 'ascend');
    ind = order(1);
    optorder = ind;
    used(ind) = 1;
    %find most match with picture
    pointmatch = [];
    for i = 1:N
        pointmatch = [pointmatch Stuff{ind,i}.nums+(used(i)*1e6)];
    end
    [blah,imord] = sort(pointmatch,'ascend');
    used(imord(1)) = 1;
    energy = 1e6;
    for i = 1:length(optorder)+1 %try all orders
        filelist = [optorder(1:i-1) imord(1) optorder(i:end)]
        [temp, newenergy] = combine(file,filelist,deb);
        if newenergy < energy
            energy = newenergy;
            newoptorder = filelist;
        end
    end
    oldpointmatch = pointmatch/2;
    oldpointmatch(imord(1)) = 0;
    optorder = newoptorder;
    ind = imord(1);

    for count = 3:N
        pointmatch = [];
        for i = 1:N
            pointmatch = [pointmatch Stuff{ind,i}.nums+(used(i)*1e6)];
        end
        pointmatch = pointmatch+oldpointmatch;
        [blah,imord] = sort(pointmatch,'ascend');
        used(imord(1)) = 1;
        energy = 1e10;
        for i = 1:length(optorder)+1 %try all orders
            filelist = [optorder(1:i-1) imord(1) optorder(i:end)]
            [temp, newenergy] = combine(file,filelist,deb);
            if newenergy < energy
                energy = newenergy;
                newoptorder = filelist;
            end
        end
        oldpointmatch = pointmatch/2;
        oldpointmatch(imord(1)) = 0;
        optorder = newoptorder;
        ind = imord(1);
    end
end

if ordertype == 1
    used = zeros(1, N); %indicate whether an image is processed in the ordering
    [blah,order] = sort(sum(matched), 'descend');
    ind = order(1);
    optorder = ind;
    used(ind) = 1;
    %find most match with picture
    pointmatch = [];
    for i = 1:N
        pointmatch = [pointmatch Stuff{ind,i}.nums*(~used(i))];
    end
    [blah,imord] = sort(pointmatch,'descend');
    used(imord(1)) = 1;
    energy = 1e6;
    for i = 1:length(optorder)+1 %try all orders
        filelist = [optorder(1:i-1) imord(1) optorder(i:end)];
        [temp, newenergy] = combine(file,filelist,deb);
        if newenergy < energy
            energy = newenergy;
            newoptorder = filelist;
        end
    end
    oldpointmatch = pointmatch/2;
    oldpointmatch(imord(1)) = 0;
    optorder = newoptorder;
    ind = imord(1);

    for count = 3:N
        pointmatch = [];
        for i = 1:N
            pointmatch = [pointmatch Stuff{ind,i}.nums*(~used(i))];
        end
        pointmatch = pointmatch+oldpointmatch;
        [blah,imord] = sort(pointmatch,'descend');
        used(imord(1)) = 1;
        energy = 1e10;
        for i = 1:length(optorder)+1 %try all orders
            filelist = [optorder(1:i-1) imord(1) optorder(i:end)];
            [temp, newenergy] = combine(file,filelist,deb);
            if newenergy < energy
                energy = newenergy;
                newoptorder = filelist;
            end
        end
        oldpointmatch = pointmatch/2;
        oldpointmatch(imord(1)) = 0;
        optorder = newoptorder;
        ind = imord(1);
    end
end

display(optorder)
out = combine(file, optorder, deb);
figure()
imagesc(out);
imwrite(out, 'step3.jpg');
pause
clear newoptorder oldpointmatch pointmatch imord out

%STEP4====================================================================
%realign
%change all matched features into canvas coordinates
for i = 1:N
    for j = 1:i-1
        if matched(i,j) == 1
            ipoints = ptsglobal(Sizes(:,i), Imloc{i}, Stuff{i,j}.points(:,1:2));
            jpoints = ptsglobal(Sizes(:,j), Imloc{j}, Stuff{i,j}.points(:,3:4));
            Stuff{i,j}.canpoints = [ipoints, jpoints];
            Stuff{j,i}.canpoints = [jpoints, ipoints];
        end
    end
end
%hold on
%temp = 5;
%temp2 = 6;
%plot(Stuff{optorder(temp),optorder(temp2)}.canpoints(:,1),Stuff{optorder(temp),optorder(temp2)}.canpoints(:,2),'r*');
%plot(Stuff{optorder(temp),optorder(temp2)}.canpoints(:,3),Stuff{optorder(temp2),optorder(temp)}.canpoints(:,4),'go');


%realign from top down
for i = N-1:-1:1
    ptsaligned = [];
    for j = N:-1:i+1
        if matched(optorder(i),optorder(j)) == 1
            ptsaligned = [ptsaligned; Stuff{optorder(i),optorder(j)}.canpoints];
        end 
    end
    %check if there are enough points
    if length(ptsaligned) < Tolerance
        %no realignment
    else
        %find half closest points to use for alignment
        %use distance transform from border as a criterion
        [dist] = closeborder(file,optorder(i:end));
        closestpoints = getclosestpoints(dist, ptsaligned);
        %hold on
        %plot(closestpoints(:,1),closestpoints(:,2),'r*');
        %plot(closestpoints(:,3),closestpoints(:,4),'go');
        %pause
        %from the canvas coordinate get the coordinate in the local picture
        localpts = ptslocal(Sizes(:,optorder(i)), Imloc{optorder(i)}, closestpoints(:,1:2));
        %figure(2)
        %imagesc(imread(file{optorder(i)}));
        %hold on
        %plot(localpts(:,1),localpts(:,2),'r*');
        %pause
        %realign according to closestpoints
        Imloc{optorder(i)} = morphblankreadjust(Sizes(:,optorder(i)), closestpoints(:,3:4), localpts);
        %readjust points
        for k = 1:N
            if k == optorder(i)
                %do nothing
            else
                if matched(optorder(i),k) == 1
                    ipoints = ptsglobal(Sizes(:,i), Imloc{optorder(i)}, Stuff{optorder(i),k}.points(:,1:2));
                    %jpoints = ptsglobal(Sizes(:,j), Imloc{j}, Stuff{i,j}.points(:,3:4));
                    Stuff{optorder(i),k}.canpoints(:,1:2) = ipoints;
                    Stuff{k,optorder(i)}.canpoints(:,3:4) = ipoints;
                end
            end
        end
    end
end

%recreate the canvas
%put them into a longggggg list of coordinates
frame = zeros(2,4*N);
for i = 0:N-1
    frame(:,i*4+1:(i+1)*4) = Imloc{i+1};
end
%imagesc(imread('b.jpg')); axis([-1000 1000 -1000 1000]);
%hold on
%plot(frame(1,:),frame(2,:),'*');

%find the global canvas
framexspan = ceil(max([frame(1,:)]))-floor(min([frame(1,:) 1]));
frameyspan = ceil(max([frame(2,:)]))-floor(min([frame(2,:) 1]));
if min(frame(1,:)) < 1
    xshift = -(1 - floor(min(frame(1,:))))
else
    xshift = 0
end
if min(frame(2,:)) < 1
    yshift = -(1 - floor(min(frame(2,:))))
else
    yshift = 0
end
canvas = [framexspan+1, frameyspan+1]
%global canvas is frameyspan+1 x framexspan+1
%realign image location
for i = 1:N
    Imloc{i}(1,:) = Imloc{i}(1,:) - xshift;
    Imloc{i}(2,:) = Imloc{i}(2,:) - yshift;
end
for i = 0:N-1
    frame(:,i*4+1:(i+1)*4) = Imloc{i+1};
end
%imagesc(imread('b.jpg')); axis([-1000 1000 -1000 1000]);
%hold on
%plot(frame(1,:),frame(2,:),'*');

%output the files seperatly in global canvas
for i = 1:N
    morphglobal(canvas, file{i}, Imloc{i});
end

deb = 1;
out = combine(file, optorder, deb);
display('Done!!');
figure();
imagesc(out);
imwrite(out,'step4.jpg')
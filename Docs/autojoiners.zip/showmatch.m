function out = showmatch(im1, im2, im1x, im1y, im2x, im2y)
%show matching points
im3 = appendimages(im1,im2);

% Show a figure with lines joining the accepted matches.
figure('Position', [100 100 size(im3,2) size(im3,1)]);
colormap('gray');
imagesc(im3);
hold on;
cols1 = size(im1,2);
for i = 1:length(im1x)
    line([im1x(i) im2x(i)+cols1], ...
         [im1y(i) im2y(i)], 'Color', 'c');  
end
plot(im1x, im1y,'*');
plot(im2x+cols1, im2y,'*');
hold off;

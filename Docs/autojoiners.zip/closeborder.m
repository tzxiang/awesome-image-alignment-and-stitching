function [dist] = closeborder(file,order)
%Find the distance from border in the big image that overlap with the first
%picture in the order (put down first)

showpix = 0;

canvas = im2double(imread(['global_' file{order(1)}(1:end-3) 'bmp']));
exclusivemask = zeros(size(canvas(:,:,1)));

mask = im2double(imread(['mask_' file{order(1)}(1:end-3) 'bmp']));
firstmask = mask;
Ix = conv2(mask,[-1 0 1],'same');  % take x derivative 
Iy = conv2(mask,[-1;0;1],'same');  % take y derivative
border = abs(Ix)+abs(Iy);

for i = 2:length(order)
    mask = im2double(imread(['mask_' file{order(i)}(1:end-3) 'bmp']));
    index = find(mask==1);
    
    exclusivemask(index) = 1;
    
    Ix = conv2(mask,[-1 0 1],'same');  % take x derivative 
    Iy = conv2(mask,[-1;0;1],'same');  % take y derivative
    tempborder = abs(Ix)+abs(Iy);
    border(index) = tempborder(index);
    
    index = [index; index+size(canvas,1)*size(canvas,2); index+2*size(canvas,1)*size(canvas,2)];
    infi = im2double(imread(['global_' file{order(i)}(1:end-3) 'bmp']));
    canvas(index) = infi(index);
    if showpix == 1;
    figure(1)
    imagesc(canvas);
    figure(2)
    imagesc(border)
    pause
    end
end


% grad = zeros(size(canvas(:,:,1)));
% for i = 1:3
%     Ix = conv2(canvas(:,:,i),[-1 0 1],'same');  % take x derivative 
%     Iy = conv2(canvas(:,:,i),[-1;0;1],'same');  % take y derivative
%     grad = abs(Ix)+abs(Iy)+grad;
% end

%find only the cross border (overlap) of the first image
border(exclusivemask == 0) = 0;
%figure(4)
%imagesc(border)
%pause
border(firstmask ~= 1) = 0;
%imagesc(border)
%pause
seen = firstmask;
seen(exclusivemask == 1) = 0;
%imagesc(seen)
%pause
expandedseen = conv2(seen,[1 1 1; 1 1 1; 1 1 1],'same');
border(expandedseen < 0.3) = 0;
%figure(4)
%imagesc(border);

%normalize value in border
border(border ~= 0) = 1;

dist = bwdist(border);
%figure(5)
%imagesc(dist);

if showpix == 1
tempcan = canvas;
index = find(border > 0.1);
tempcan(index) = 0;
tempcan(index+size(canvas,1)*size(canvas,2)) = 1;
tempcan(index+size(canvas,1)*size(canvas,2)) = 0;
figure(3);
imagesc(tempcan);
end

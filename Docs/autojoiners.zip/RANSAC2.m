function [outax, outay, outbx, outby] = RANSAC2(ax, ay, bx, by)
%[outax, outay, outbx, outby] = RANSAC(ax, ay, bx, by, num)
%num = total number of matched features
%from proj4 changed to meets the similiarity transform instead of the
%projection

thres = 400; %deviation allowed to be considered inlier

len = length(ax);

maxin = 0;
minoutlier = ones(1,length(ax));

for i = 1:1000 %run 500 iterations
    goodrand =0;
    while goodrand == 0
        picked = randint(1, 3, [1, len]);
        goodrand = 1;
        if(sum(picked - picked(1) == 0) > 1) goodrand = 0; end
        if(sum(picked - picked(2) == 0) > 1) goodrand = 0; end
        if(sum(picked - picked(3) == 0) > 1) goodrand = 0; end
    end
    %picked
    Hab = computeS([ax(picked), ay(picked)]',[bx(picked), by(picked)]');
    %bhat = unscale(Hab*[ax(picked)'; ay(picked)'; ones(1,4)])
    %bx(picked)
    %by(picked)
    bhat = Hab*[ax'; ay'; ones(1,len)];
    outlier = ((bhat(1,:) - bx').^2 + (bhat(2,:) - by').^2) > thres;
    numinlier = len-sum(outlier);
    if(numinlier > maxin)
        maxin = numinlier;
        minoutlier = outlier;
        tbest = picked;
    end
    %pause
end
inlier = ~minoutlier;
outax = ax(inlier);
outay = ay(inlier);
outbx = bx(inlier);
outby = by(inlier);
%best(1) = sum(inlier(1:tbest(1)));
%best(2) = sum(inlier(1:tbest(2)));
%best(3) = sum(inlier(1:tbest(3)));
%best = tbest;
% best = [4 , 9, 33];
% H21 = computeS([bx(best), by(best)]',[ax(best), ay(best)]');
% im2 = zeros(289,338);
% size2 = size(im2);
% frame = H21*[size2(1), 1, 1; size2(1), size2(2), 1; 1, size2(2), 1; 1, 1, 1]';
% H21
% frame
% best
function [newim2loc] = morphblank(size1, size2, im1loc, im2loc, im1_pts, im2_pts)
% find the location of im2 in the space if it were to be joined with im1
% size1 and size2 are the size of im1 and im2
% im1_pts and im2_pts are the features of im1_pts and im2_pts in normal
% coordinates
% im1loc are the 4 corners of the im1
% the location are encoded as [lowerleft lowerright topright topleft][x;y]

%simple = 4; %method of blending

size1;% = size(im1);
size2;% = size(im2);

%find the cooresponding im1_pts in im1loc
orig = [1, size1(1); size1(2), size1(1); size1(2), 1; 1, 1]';
H11 = computeS(orig,im1loc);
temp = [im1_pts'; ones(1,length(im1_pts))];
newim1_pts = H11*temp;

%find the cooresponding im2_pts in im2loc
orig = [1, size2(1); size2(2), size2(1); size2(2), 1; 1, 1]';
H22 = computeS(orig,im2loc);
temp = [im2_pts'; ones(1,length(im2_pts))];
newim2_pts = H22*temp;

H21 = computeS((newim2_pts), (newim1_pts));

%find the im2loc in im1loc
%frame = [lowerleft lowerright topright topleft]
temp = [im2loc; ones(1,4)];
frame = H21*temp;
%imagesc(imread('scene.pgm')); axis([-1000 1000 -1000 1000]);
%hold on
%plot(im1loc(1,:),im1loc(2,:),'*');
%plot(frame(1,:),frame(2,:),'*r');
newim2loc = frame;

% %bigframe = [left right; top bot]
% frame
% % bigframe = [floor(min([1, frame(1,1), frame(1,4)])),ceil(max([size1(2), frame(1,2), frame(1,3)]));
% %             floor(min([1, frame(2,3), frame(2,4)])),ceil(max([size1(1), frame(2,1), frame(2,2)]))]
% % %return
% % if(bigframe(1) < 1)
% %     xshift = -1 + bigframe(1);
% % else
% %     xshift = 0;
% % end
% % if(bigframe(2) < 1)
% %     yshift = -1 + bigframe(2);
% % else
% %     yshift = 0;
% % end
% % bigframef(1,:) = bigframe(1,:) - xshift;
% % bigframef(2,:) = bigframe(2,:) - yshift;
% % yshift
% % xshift
% framexspan = ceil(max([frame(1,:), size(im1,2)]))-floor(min([frame(1,:), 1]));
% frameyspan = ceil(max([frame(2,:), size(im1,1)]))-floor(min([frame(2,:), 1]));
% if min(frame(1,:)) < 1
%     xshift = -(1 - floor(min(frame(1,:))));
% else
%     xshift = 0;
% end
% if min(frame(2,:)) < 1
%     yshift = -(1 - floor(min(frame(2,:))));
% else
%     yshift = 0;
% end
% xshift
% yshift
% H12f = inv([1 0 -xshift; 0 1 -yshift; 0 0 1]*[H21; 0 0 1]);
% %H12f = [computeS((im1_pts)', (im2_pts)')];%; 0 0 1];
% %points2 = unscale(H12f*[frame; 1 1 1 1])
% %bigframef
% out = zeros(frameyspan+1, framexspan+1, 4);
% frameyspan
% size(out)
% 
% %copy im1 to out
% out1 = out;
% size(im1)
% size(out1(1-yshift:size1(1)-yshift, 1-xshift:size1(2)-xshift, :))
% out1(1-yshift:size1(1)-yshift, 1-xshift:size1(2)-xshift, :) = im1;
% 
% %find im2 in new coords
% out2 = out;
% %find the rectangle that fits the picture
% frame(1,:) = frame(1,:) - xshift;
% frame(2,:) = frame(2,:) - yshift;
% frame
% xspan = [ceil(min(frame(1,:))), floor(max(frame(1,:)))];
% yspan = [ceil(min(frame(2,:))), floor(max(frame(2,:)))];
% 
% temp(3, 1:(xspan(2) - xspan(1))+1) = 1;
% ind = zeros((xspan(2) - xspan(1) + 1)*(yspan(2) - yspan(1) + 1),2);
% wid = xspan(2) - xspan(1) + 1;
% 
% % figure(2);
% % imagesc(im1(:,:,1:3));
% % hold on;
% % figure(3);
% % imagesc(im2(:,:,1:3));
% % hold on
% %figure(4);
% %imagesc(im1(:,:,1:3));
% p = 1;
% for j = yspan(1):yspan(2)     
%     temp(1, :) = xspan(1):xspan(2);
%     temp(2, :) = j;
% %     figure(2);
% %     plot(temp(1,:),temp(2,:),'*r');
%     ind(p:p+wid-1,:) = unscale(H12f*temp)';
% %     figure(3);
% %     plot(ind(p:p+wid-1,1),ind(p:p+wid-1,2),'*g');
% %     
% %     out2(j,xspan(1):xspan(2),4) = interp2(ones(size2(1), size2(2)), ind(p:p+wid-1,1), ind(p:p+wid-1,2),'*linear', 0);
% %     figure(4); imagesc(out2(:,:,4));
%     %pause
%     p = p+wid;
% end
% 
% %plot(frame(1,:),frame(2,:),'*');
% out2(yspan(1):yspan(2), xspan(1):xspan(2),1) = reshape(interp2(im2(:,:,1), ind(:,1), ind(:,2),'*linear', 0), [wid, yspan(2)-yspan(1)+1])';
% out2(yspan(1):yspan(2), xspan(1):xspan(2),2) = reshape(interp2(im2(:,:,2), ind(:,1), ind(:,2),'*linear', 0), [wid, yspan(2)-yspan(1)+1])';
% out2(yspan(1):yspan(2), xspan(1):xspan(2),3) = reshape(interp2(im2(:,:,3), ind(:,1), ind(:,2),'*linear', 0), [wid, yspan(2)-yspan(1)+1])';
% out2(yspan(1):yspan(2), xspan(1):xspan(2),4) = reshape(interp2(ones(size2(1), size2(2)), ind(:,1), ind(:,2),'linear', 0), [wid, yspan(2)-yspan(1)+1])';
% size(out2)
% %figure(4);
% %imagesc(im1(:,:,1:3));
% %hold on
% %imagesc(out2(:,:,4));
% 
% if(simple == 1) %0.5 at overlap
% out(:,:,4) = out1(:,:,4) + out2(:,:,4);
% temp = out1(:,:,4)./out(:,:,4);
% temp(isnan(temp)) = 0;
% out1(:,:,4) = temp;
% temp = out2(:,:,4)./out(:,:,4);
% temp(isnan(temp)) = 0;
% out2(:,:,4) = temp;
% 
% out(:,:,1) = out1(:,:,1).*out1(:,:,4) + out2(:,:,1).*out2(:,:,4);
% out(:,:,2) = out1(:,:,2).*out1(:,:,4) + out2(:,:,2).*out2(:,:,4);
% out(:,:,3) = out1(:,:,3).*out1(:,:,4) + out2(:,:,3).*out2(:,:,4);
% return
% end
% 
% if simple == 2 %distance transform
% edges1 = (out1(:,:,4)==0);
% edges1 = bwdist(edges1);
% edges(out1(:,:,4) == 0) = 0;
% 
% edges2 = (out2(:,:,4)==0);
% edges2 = bwdist(edges2);
% edges2(out2(:,:,4) == 0) = 0;
% 
% edges = edges1./(edges1 + edges2);
% edges(isnan(edges)) = 0;
% 
% nedges = 1-edges;
% 
% temp = out2(:,:,1).*(nedges);
% temp(out2(:,:,4) == 0) = 0;
% out(:,:,1) = out1(:,:,1).*edges + temp;
% temp = out2(:,:,2).*(nedges);
% temp(out2(:,:,4) == 0) = 0;
% out(:,:,2) = out1(:,:,2).*edges + temp;
% temp = out2(:,:,3).*(nedges);
% temp(out2(:,:,4) == 0) = 0;
% out(:,:,3) = out1(:,:,3).*edges + temp;
% out(:,:,4) = out1(:,:,4)|out2(:,:,4);
% return
% end
% 
% 
% if simple == 3 %laplacian blending
%     
% h = fspecial('gaussian', [19 19], 1.5);
% out1low(:,:,3) = filter2(h, out1(:,:,3), 'same');
% out1low(:,:,1) = filter2(h, out1(:,:,1), 'same');
% out1low(:,:,2) = filter2(h, out1(:,:,2), 'same');
% 
% out1high = out1(:,:,1:3) - out1low;
% 
% out2low(:,:,3) = filter2(h, out2(:,:,3), 'same');
% out2low(:,:,1) = filter2(h, out2(:,:,1), 'same');
% out2low(:,:,2) = filter2(h, out2(:,:,2), 'same');
% 
% out2high = out2(:,:,1:3) - out2low;
% 
% edges1 = (out1(:,:,4)==0);
% edges1 = bwdist(edges1);
% edges(out1(:,:,4) == 0) = 0;
% 
% edges2 = (out2(:,:,4)==0);
% edges2 = bwdist(edges2);
% edges2(out2(:,:,4) == 0) = 0;
% 
% edges = edges1./(edges1 + edges2);
% edges(isnan(edges)) = 0;
% nedges = 1-edges;
% 
% edges1 = out1(:,:,4);
% edges1(edges < 0.5) = 0;
% 
% edges2 = out2(:,:,4);
% 
% edges2(edges >= 0.5) = 0;
% 
% temp = out2low(:,:,1).*(nedges);
% temp(out2(:,:,4) == 0) = 0;
% out(:,:,1) = out1low(:,:,1).*edges + temp + out1high(:,:,1).*edges1 + out2high(:,:,1).*edges2;
% temp = out2low(:,:,2).*(nedges);
% temp(out2(:,:,4) == 0) = 0;
% out(:,:,2) = out1low(:,:,2).*edges + temp + out1high(:,:,2).*edges1 + out2high(:,:,2).*edges2;
% temp = out2low(:,:,3).*(nedges);
% temp(out2(:,:,4) == 0) = 0;
% out(:,:,3) = out1low(:,:,3).*edges + temp + out1high(:,:,3).*edges1 + out2high(:,:,3).*edges2;
% out(:,:,4) = out1(:,:,4)|out2(:,:,4);
% out(out>1) = 1;
% out(out<0) = 0;
% end
% 
% if(simple == 4) %pick on on top
% % out(:,:,4) = out1(:,:,4) + out2(:,:,4);
% % temp = out1(:,:,4)./out(:,:,4);
% % temp(isnan(temp)) = 0;
% % out1(:,:,4) = temp;
% % temp = out2(:,:,4)./out(:,:,4);
% % temp(isnan(temp)) = 0;
% % out2(:,:,4) = temp;
% temp = out1(:,:,4);
% temp(out2(:,:,4)>0) = 0;
% out1(:,:,4) = temp;
% out(:,:,1) = out1(:,:,1).*out1(:,:,4) + out2(:,:,1).*out2(:,:,4);
% out(:,:,2) = out1(:,:,2).*out1(:,:,4) + out2(:,:,2).*out2(:,:,4);
% out(:,:,3) = out1(:,:,3).*out1(:,:,4) + out2(:,:,3).*out2(:,:,4);
% return
% end
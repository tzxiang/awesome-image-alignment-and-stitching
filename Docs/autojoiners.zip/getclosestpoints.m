function closestpoints = getclosestpoints(dist, ptsaligned);
%using the distance transform from the border (dist) find the 10 closest
%correspondance to align. ptsaligned is the in the form [im1x, im1y, im2x,
%im2y]. These points are in the canvas coordinates

%use the mean of the points to represent the feature in dist transform
meanpts = (ptsaligned(:,1:2) + ptsaligned(:,3:4))/2;

%sample the dist function by the meanpts
vals = interp2(dist, meanpts(:,1), meanpts(:,2),'nearest', 0);
[blah, order] = sort(vals, 'ascend');

closestpoints = ptsaligned(order(1:10),1:4);

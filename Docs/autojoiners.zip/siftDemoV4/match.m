%Modified by Ekapol Chuangsuwnaich for use in Automatic joiners
%
% [num,loc1m,loc2m] = match(image1, image2)
%
% This function reads two images, finds their SIFT features, and
%   displays lines connecting the matched keypoints.  A match is accepted
%   only if its distance is less than distRatio times the distance to the
%   second closest match.
% It returns the number of matches displayed.
% ====Modified to Return the locations of the match in image1 and image2
% ====The points are in a Matrix of size match x 2
%
% Example: match('scene.pgm','book.pgm');

function [num,loc1m,loc2m] = match(image1, image2)

% Find SIFT keypoints for each image
[im1, des1, loc1] = sift(image1);
[im2, des2, loc2] = sift(image2);

% For efficiency in Matlab, it is cheaper to compute dot products between
%  unit vectors rather than Euclidean distances.  Note that the ratio of 
%  angles (acos of dot products of unit vectors) is a close approximation
%  to the ratio of Euclidean distances for small angles.
%
% distRatio: Only keep matches in which the ratio of vector angles from the
%   nearest to second nearest neighbor is less than distRatio.
distRatio = 0.6;   

% For each descriptor in the first image, select its match to second image.
des2t = des2';                          % Precompute matrix transpose
for i = 1 : size(des1,1)
   dotprods = des1(i,:) * des2t;        % Computes vector of dot products
   [vals,indx] = sort(acos(dotprods));  % Take inverse cosine and sort results

   % Check if nearest neighbor has angle less than distRatio times 2nd.
   if (vals(1) < distRatio * vals(2))
      match(i) = indx(1);
   else
      match(i) = 0;
   end
end

num = sum(match > 0);
%create the matrix that contains the matched locations
loc1m = zeros(num,2);
loc2m = zeros(num,2);
loc1m = [loc1(match>0,2),loc1(match>2,1)];
matchtemp = match(match>0);
loc2m = [loc2(matchtemp,2), loc2(matchtemp,1)];


% Create a new image showing the two images side by side.
im3 = appendimages(im1,im2);

% Show a figure with lines joining the accepted matches.
figure('Position', [100 100 size(im3,2) size(im3,1)]);
colormap('gray');
imagesc(im3);
hold on;
cols1 = size(im1,2);
for i = 1: size(des1,1)
  if (match(i) > 0)
%     plot(loc1(i,2), loc1(i,1),'*');
%     plot(loc2(match(i),2)+cols1, loc2(match(i),1),'*');
    line([loc1(i,2) loc2(match(i),2)+cols1], ...
         [loc1(i,1) loc2(match(i),1)], 'Color', 'c');
  end
  plot(loc1m(:,1), loc1m(:,2),'*');
  plot(loc2m(:,1)+cols1, loc2m(:,2),'*');
end
hold off;

fprintf('Found %d matches.\n', num);
% close all
% showmatch(im1, im2, loc1m(:,1), loc1m(:,2), loc2m(:,1), loc2m(:,2));
% 


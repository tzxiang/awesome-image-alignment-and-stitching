function [out2] = morphglobal(canvas, im2name, im2loc)
% morph the im2name (filename) into the global canvas specified by canvas [sizex sizey]
% the position of im2 is specified in im2loc
% the convention of im2loc is the same as morphblank
% write the output file as (global_filename) and a mask file mask_filename

im2 = im2double(imread(im2name));
size2 = size(im2);

orig = [1, size2(1); size2(2), size2(1); size2(2), 1; 1, 1]';
H12f = computeS(im2loc,orig);

out2 = zeros(canvas(2), canvas(1), 4);
%size(out2)
%find im2 in new coords
%out2 = out;
%find the rectangle that fits the picture
%frame(1,:) = frame(1,:) - xshift;
%frame(2,:) = frame(2,:) - yshift;
%frame
xspan = [ceil(min(im2loc(1,:))), floor(max(im2loc(1,:)))];
yspan = [ceil(min(im2loc(2,:))), floor(max(im2loc(2,:)))];

temp(3, 1:(xspan(2) - xspan(1))+1) = 1;
ind = zeros((xspan(2) - xspan(1) + 1)*(yspan(2) - yspan(1) + 1),2);
wid = xspan(2) - xspan(1) + 1;

% figure(2);
% imagesc(im1(:,:,1:3));
% hold on;
% figure(3);
% imagesc(im2(:,:,1:3));
% hold on
%figure(4);
%imagesc(im1(:,:,1:3));
p = 1;
for j = yspan(1):yspan(2)     
    temp(1, :) = xspan(1):xspan(2);
    temp(2, :) = j;
%     figure(2);
%     plot(temp(1,:),temp(2,:),'*r');
    ind(p:p+wid-1,:) = (H12f*temp)';
%     figure(3);
%     plot(ind(p:p+wid-1,1),ind(p:p+wid-1,2),'*g');
%     
%     out2(j,xspan(1):xspan(2),4) = interp2(ones(size2(1), size2(2)), ind(p:p+wid-1,1), ind(p:p+wid-1,2),'*linear', 0);
%     figure(4); imagesc(out2(:,:,4));
    %pause
    p = p+wid;
end

%plot(frame(1,:),frame(2,:),'*');
out2(yspan(1):yspan(2), xspan(1):xspan(2),1) = reshape(interp2(im2(:,:,1), ind(:,1), ind(:,2),'*linear', 0), [wid, yspan(2)-yspan(1)+1])';
out2(yspan(1):yspan(2), xspan(1):xspan(2),2) = reshape(interp2(im2(:,:,2), ind(:,1), ind(:,2),'*linear', 0), [wid, yspan(2)-yspan(1)+1])';
out2(yspan(1):yspan(2), xspan(1):xspan(2),3) = reshape(interp2(im2(:,:,3), ind(:,1), ind(:,2),'*linear', 0), [wid, yspan(2)-yspan(1)+1])';
out2(yspan(1):yspan(2), xspan(1):xspan(2),4) = reshape(interp2(ones(size2(1), size2(2)), ind(:,1), ind(:,2),'*linear', 0), [wid, yspan(2)-yspan(1)+1])';
%size(out2)

%imagesc(out2(:,:,1:3));
imwrite(out2(:,:,1:3),['global_' im2name(1:end-3) 'bmp']);
imwrite(out2(:,:,4),['mask_' im2name(1:end-3) 'bmp']);
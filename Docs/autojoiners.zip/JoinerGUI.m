function varargout = JoinerGUI(varargin)
% JOINERGUI M-file for JoinerGUI.fig
%      JOINERGUI, by itself, creates a new JOINERGUI or raises the existing
%      singleton*.
%
%      H = JOINERGUI returns the handle to a new JOINERGUI or the handle to
%      the existing singleton*.
%
%      JOINERGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in JOINERGUI.M with the given input arguments.
%
%      JOINERGUI('Property','Value',...) creates a new JOINERGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before JoinerGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to JoinerGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help JoinerGUI

% Last Modified by GUIDE v2.5 14-Dec-2007 22:28:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @JoinerGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @JoinerGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before JoinerGUI is made visible.
function JoinerGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to JoinerGUI (see VARARGIN)

% Choose default command line output for JoinerGUI
handles.output = hObject;

handles.filename = varargin{1};
handles.optorder = varargin{2};

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes JoinerGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = JoinerGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1

%plot original
current = handles.N-get(handles.listbox1,'Value')+1;
currentim = imread(handles.files{handles.optorder(current)});

axes(handles.original);
imagesc(currentim);
axis off;

%plot current
currentname = handles.files{handles.optorder(current)};
currentname = ['global_' currentname(1:end-3) 'bmp'];
currentim = imread(currentname);

axes(handles.current);
imagesc(currentim);
axis off;


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in up.
function up_Callback(hObject, eventdata, handles)
% hObject    handle to up (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



%check whether up is possible
currentindex = handles.N-get(handles.listbox1,'Value')+1;
if currentindex ~= handles.N
    temp = handles.optorder(currentindex);
    handles.optorder(currentindex) = handles.optorder(currentindex+1);
    handles.optorder(currentindex+1) = temp;
    
    ind = handles.N;
    for i = 1:handles.N
        sortedlist{ind} = handles.files{handles.optorder(i)};
        ind = ind-1;
    end
    set(handles.listbox1,'String',sortedlist);
    set(handles.listbox1,'Value',handles.N-currentindex);

    % Update handles structure
    guidata(hObject, handles);
end

% --- Executes on button press in down.
function down_Callback(hObject, eventdata, handles)
% hObject    handle to down (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%check whether down is possible
currentindex = handles.N-get(handles.listbox1,'Value')+1;
if currentindex ~= 1
    temp = handles.optorder(currentindex);
    handles.optorder(currentindex) = handles.optorder(currentindex-1);
    handles.optorder(currentindex-1) = temp;
    
    ind = handles.N;
    for i = 1:handles.N
        sortedlist{ind} = handles.files{handles.optorder(i)};
        ind = ind-1;
    end
    set(handles.listbox1,'String',sortedlist);
    set(handles.listbox1,'Value',handles.N-currentindex+2);

    % Update handles structure
    guidata(hObject, handles);
end



% --- Executes on button press in loaddata.
function loaddata_Callback(hObject, eventdata, handles)
% hObject    handle to loaddata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.files = textread(handles.filename,'%s','delimiter','\n','whitespace','');
handles.N = length(handles.files);
ind = handles.N;
for i = 1:handles.N
    sortedlist{ind} = handles.files{handles.optorder(i)};
    ind = ind-1;
end
set(handles.listbox1,'String',sortedlist);

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in view.
function view_Callback(hObject, eventdata, handles)
% hObject    handle to view (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%plot original
current = handles.N - get(handles.listbox1,'Value') + 1;
currentim = imread(handles.files{handles.optorder(current)});

axes(handles.original);
imagesc(currentim);
axis off;

%plot current
currentname = handles.files{handles.optorder(current)};
currentname = ['global_' currentname(1:end-3) 'bmp'];
currentim = imread(currentname);

axes(handles.current);
imagesc(currentim);
axis off;

%plot bigpic
currentim = combine(handles.files, handles.optorder, 1);

axes(handles.bigpic);
imagesc(currentim);
axis off;


% --- Executes on button press in lucky.
function lucky_Callback(hObject, eventdata, handles)
% hObject    handle to lucky (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

current = handles.N - get(handles.listbox1,'Value') + 1;

%random order output
temp = randn(1,handles.N);
[blah, ordering] = sort(temp);

handles.optorder = handles.optorder(ordering);

current = find(ordering==current);
ind = handles.N;
for i = 1:handles.N
    sortedlist{ind} = handles.files{handles.optorder(i)};
    ind = ind-1;
end
set(handles.listbox1,'String',sortedlist);
set(handles.listbox1,'Value',handles.N-current+1);

%plot bigpic
currentim = combine(handles.files, handles.optorder, 1);

axes(handles.bigpic);
imagesc(currentim);
axis off;

% Update handles structure
guidata(hObject, handles);



% --- Executes on button press in medone.
function medone_Callback(hObject, eventdata, handles)
% hObject    handle to medone (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = combine(handles.files, handles.optorder, 1);
imwrite(handles.output,'GUIoutput.jpg');
fprintf('New ordering is \n');
handles.optorder
% Update handles structure
guidata(hObject, handles);

delete(handles.figure1);
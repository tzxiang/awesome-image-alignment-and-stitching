This Matlab package takes in a set of picture and produce "joiners" automatically. 
(Check out http://flickr.com/groups/joiners/ to see what joiners look like).

If you have any questions/comments about the code feel free to email me at echuangs@andrew.cmu.edu
If you happen to modify the code to make it more robust, please send me a copy as well :).

DISCLAIMER
This code is written as a final project for Carnegie Mellon University Fall 07 Computational Photography class
by Ekapol Chuangsuwanich.
The SIFT code is originally written by David Lowe, and according to his webpage:

This demo software (SIFT) is provided for research purposes only. A license must be obtained from the University of British Columbia for any commercial applications. The sofware is protected under a US patent as listed below. This demo software is a research implementation, while the licensed software has been further optimized for speed and to provide a range of other capabilities. See the LICENSE file provided with the demo software.

At the moment, the code is BUGGY, if the set of input images forms more than 1 group of joiners.
The code will prune any images that does not match with any other images in the set. It will also
tell you which image it pruned.
However, if that image match with each other in some way, ie. you have 2 set of joiners, 
the result might not be pleasing.
====================================================================================


====================================================================================
This package consist of 3 main parts
1. SIFT (match.m)
2. joiners.m
3. JoinerGUI
====================================================================================


====================================================================================
How to use
1. create a text file that contains the list of names of the
The file should be the following format

cat.jpg
dog.jpg
bird.jpg
... 

The files need to be in the same folder as the code.

2. Use [out,optorder] = joiners(namelist) to get the output
namelist is the String that contains name of the file
out is the resulting output
optorder is the ordering of the file according to the files in the list where the first value specify the bottommost picture of the joiner.

OPTIONAL
3. Use JoinerGUI to reorder the output in some more artistic way by calling JoinerGUI(namelist,optorder)

(Non-Window Users)
SIFT has a win32 version and a unix version. Window users do not need to do anything special for the code to work.
Unix users need to compile the c files in the SIFT package for it to work. I have not try using
the unix version yet, but it should work. Consult SIFT_readme on how to use SIFT on linux with MATLAB
====================================================================================


====================================================================================
joiners.m explained

There are 4 main steps to the file.
1. Call match.m on each pair of files given. It prunes any image that does not match with any other image.
After this, the program assumes that the images forms a fully connected graph SOMEHOW! If at this stage your 
set of images does not form 1 graph, the results will be bad as stated in the DISCLAIMER. It also produces files
that contain the SIFT feature points named SIFT_"filename".mat.
INPUT images' name
OUTPUT pairwised feature points

2. Find global alignment. MATLAB will pause and show the output of this stage using the ordering of the input files.
This stage also produces images that show each image in the global canvas (global_"filename".bmp) and it's mask (mask_"filename".bmp)
You can use these intermediete images with your favorite image editor to get more artistic results. It also writes a file named step2.jpg
that show the global canvas.
INPUT pairwised feature points
OUTPUT 4 corners of each image in the global canvas

3. Find optimal ordering. MATLAB will pause and show the output of this stage. It also writes a file name step3.jpg that show the ordered global canvas.
INPUT all the intermediete images from step 2.
OUTPUT best ordering

4. Readjustment. This part realign all the images. It also overwrites the "global" and "mask" files in step 2. (Change the code if you do not want this to happen). Writes a file name step4.jpg that show the output of the whole process.
INPUT output from the previous 3 steps
OUTPUT joiners
====================================================================================


====================================================================================
GUI explained

The GUI is used for reordering the output from joiners.m to get more artistic results. However, in some cases, it is better to use it on the output of step 2.

1. Pressing Load data will load the images and the optimal ordering.
2. Order as pleased (Highest in the list means the top most layer)
3. Hit view to generate the output.
4. Hit I'm done to write the output file GUIoutput.jpg

I'm feeling lucky! will randomize the ordering.

You might get better result if you run output ordering of the GUI through step 4 again.
====================================================================================
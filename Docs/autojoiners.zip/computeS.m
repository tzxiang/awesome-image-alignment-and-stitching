function [H ,c, R, t] = computeS(pts1,pts2)
%Compute Similarity transform c (scale) R (rotation) and t (transition)
%st ||pt2 - c(R*pts1+t)|| is minimized
%pts are in the form [x1 x2 ... xn; y1 y2 ... yn]
%H is the overall transform st H*pts1 -> pts2


mean1 = mean(pts1,2);
mean2 = mean(pts2,2);
var1 = sum(((pts1(1,:)-mean1(1)).^2+(pts1(2,:)-mean1(2)).^2))/length(pts1);
%((pts1(1,:)-mean1(1)).^2+(pts1(2,:)-mean1(2)).^2)
var2 = sum(((pts2(1,:)-mean2(1)).^2+(pts2(2,:)-mean2(2)).^2))/length(pts1);

cov12 = zeros(2,2);
for i = 1:length(pts1)
    cov12 = cov12 + (pts2(:,i)-mean2)*(pts1(:,i)-mean1)';
end
cov12 = cov12./length(pts1);
[U,D,V] = svd(cov12);

if det(U)*det(V) < 0.0001 || det(U)*det(V) > -0.0001 %rounding errors for det(U)*det(V)
    S = eye(2);
else
    S = [1,0;,0,-1];
end
R = U*S*V';
c = trace(D*S)/var1;
t = mean2 - c*R*mean1;
H = [c*R, t];
%e = var2 - trace(D*S).^2/var1;

% temp = sum((pts1(1,:)-mean1(1)).^2+(pts1(2,:)-mean1(2)).^2)/length(pts1)
% temp = sum((pts2(1,:)-mean2(1)).^2+(pts2(2,:)-mean2(2)).^2)/length(pts2)
% 
% covaa = zeros(2,2);
% for i = 1:3
% covaa = covaa + (pts2(:,i)-mean2)*(pts1(:,i)-mean1)';
% end
% covaa = covaa./3

function [canim2pts] = ptsglobal(size2, im2loc, im2pts)
% compute the new feature points of im2 in the canvas

orig = [1, size2(1); size2(2), size2(1); size2(2), 1; 1, 1]';
H21 = computeS(orig,im2loc);
temp = [im2pts'; ones(1,length(im2pts))];
canim2pts = (H21*temp)';
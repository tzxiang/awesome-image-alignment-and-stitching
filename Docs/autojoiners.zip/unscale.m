function outpts = unscale(pts)
%unscale the coordinates
outpts(1,:) = pts(1,:)./pts(3,:);
outpts(2,:) = pts(2,:)./pts(3,:);

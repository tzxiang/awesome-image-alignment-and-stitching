% This implementation can handle scale change 0.5 ~ 2, rotation change -45
% ~ 45. 
% 
% The program is tested on MATLAB 7.12.0 (R2011a). MEX files for linux 64
% is compiled using gcc version "4.4.6-11ubuntu2)". 
% 
% VL_SIFT is required to run this program. Make sure it is on your MATLAB
% PATH. Please refer to http://www.vlfeat.org/
% 
% For further information, please refer to our paper "Aligning Images in the Wild"
%
% https://docs.google.com/open?id=0B5SQ_68fwV9ORUVTMXkwOEIwYjA

disp('Usage: [vx,vy,warp,overlay] = AlignInternetImages(filename1, filename2)');
fprintf('\n');
disp('Input  Params:');
disp('filename1    input image file 1 (type string)');
disp('filename2    input image file 2 (type string)');
fprintf('\n');
disp('Output Params:');
disp('vx         velocity field from image 2 to image 1 (x or horizontal direction)');
disp('vy         velocity field from image 2 to image 1 (y or vertical direction)');
disp('warp       warped image 1 (note this is a reverse warp from image 1 to image 2,');
disp('           oppopsite with the direction of velocity field)');
disp('overlay    warp overlayed with image 2 (the green channel of warp is replaced');
disp('           with that of image 2)');


filename1 = 'machu_a.jpg';
filename2 = 'machu_b.jpg';
tic
[vx, vy, warp, overlay] = AlignInternetImages(filename1, filename2);
toc
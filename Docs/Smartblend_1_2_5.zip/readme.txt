Smart Blending Demo console application.

Fight:
 Nonseamed objects
 Exposure difference
 Ghosting
 Parallax

Create:
 Tileable (Seamless) textures, without geometric changes

This software is copyrighted by:  Michael Norel (minorlogic@yahoo.com)


Project uses "DevIL" library:
DevIL can be found at http://www.imagelib.org and http://openil.sourceforge.net
Project uses "LibTif" library:


Options:

All names without "-" character is input file names.

-o define output file name with extension. 
-xoff offset by x of the next following image
-yoff offset by y of the next following image

-DER Distance Error Relative 
  Weight the visual error in overlap zone with kind of distance error (0.0 - 1.0 default 0.25)

-DEC Distance Error Constant 
  Add to visual error in overlap zone some kind of distance error (0.0 - 1.0 default 0.094)

-MinSize  Equivalent of minimal Gaussian pyramid in Multiresolution Spline ( 0-MAX_INT default 2)

-MaxComp  Maximal complexity of search of Minimal error seam line. ( 1-MAX_INT default 81920) 
          higher values  give better quality, but longer processing time

-TSmooth  Transition line smooth.  (0 - MAX_INT  default 0) 

-HiPassLevel  Level of frequency for HI Pass filter (0 - MAX_INT  default 4) 
  Hi Pass filter width  = OverlapZoneSize/(2^HiPassLevel)

-SeamVerbose  Create intermediate images illustrating Beast Seam search

-PyramidVerbose Create intermediate images illustrating Pyramid operations

-HorWrap Wrap panorama with  HorWrap parameter width ( blend image from 0 to HorWrap)

-WrapMode  0 - no wrap , 1 - simple mode horizontal wrap
 in WrapMode 1 if HorWrap is not defined  HorWrap = Full Blended Result Width 
 

-w  same as "-WrapMode 1" to be compartible with programs using Enblend

-v  IGNORED just to be compartible with programs using Enblend



TODO:

Add parameter, mixing direct error and high pass error
Write documentation, anybody want help ?
Gradient blending.
Morphing feature to avoid strong geometric errors.




